var APP_DATA = {
  "scenes": [
    {
      "id": "0-sovrum",
      "name": "Sovrum",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "yaw": 0.06820726402126809,
        "pitch": 0.09896399744370044,
        "fov": 1.2739945160662665
      },
      "linkHotspots": [
        {
          "yaw": 0.015577540581606542,
          "pitch": 0.04248521227262003,
          "rotation": 0,
          "target": "1-labb"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-labb",
      "name": "Labb",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "yaw": 2.4324582543672193,
        "pitch": 0.1951002518513345,
        "fov": 1.2739945160662665
      },
      "linkHotspots": [
        {
          "yaw": 2.9984838374453835,
          "pitch": 0.08091043667182518,
          "rotation": 0,
          "target": "0-sovrum"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.9031224387804153,
          "pitch": -0.02398821227551906,
          "title": "Kontor",
          "text": "Oscars Kontor"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
